# programme.py
import commun as com #Appelle le programme commun et le renomme en com
print(com.xor(True, 2 != 2)) #Appelle la fonction xord du programme commun renommé
