#!/usr/bin/env python
# -*- coding: utf-8 -*-
 
from tkinter import *
from tkinter.messagebox import *

fenetre = Tk()

photo = PhotoImage(file="ma_photo.png")

canvas = Canvas(fenetre,width=800, height=921)
canvas.create_image(0, 0, anchor=NW, image=photo)
canvas.pack()


fenetre.mainloop()
